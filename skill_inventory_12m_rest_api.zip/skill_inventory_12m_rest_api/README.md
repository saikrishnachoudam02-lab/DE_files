# Skill Inventory 12M Mock REST API

A realistic REST API for practicing **ADF REST API ingestion** with a 12-million-record source.

## What it provides

- Exactly **12,000,000 logical records**
- No need to store a giant 12M-row JSON file
- Deterministic pseudo-random data
- Offset/limit pagination
- Maximum 10,000 records per request
- Skill/status filters
- Pagination metadata
- Cloud Academy-like employee skill inventory fields

## Run locally

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt

uvicorn app:app --host 0.0.0.0 --port 8000
```

Open:

http://localhost:8000/docs

## Test APIs

First 1,000 records:

```text
http://localhost:8000/api/v1/skill-inventory?offset=0&limit=1000
```

Next 1,000:

```text
http://localhost:8000/api/v1/skill-inventory?offset=1000&limit=1000
```

Maximum batch:

```text
http://localhost:8000/api/v1/skill-inventory?offset=0&limit=10000
```

Filter:

```text
http://localhost:8000/api/v1/skill-inventory?offset=0&limit=1000&skill=Python
```

## ADF practice

Use an ADF REST linked service pointing to:

```text
http://<your-host>:8000
```

Relative URL:

```text
api/v1/skill-inventory?offset=0&limit=1000
```

For a real remote ADF test, deploy this API to a public HTTPS host. ADF cannot normally call `localhost` on your personal computer.

### Recommended ADF design

```text
Lookup / Set Variables
        |
        v
Until / ForEach pagination loop
        |
        v
REST Copy Activity
        |
        v
ADLS Gen2
        |
        v
Bronze
```

Use:

- `offset` as the pagination state
- `limit=10000` as the batch size
- `next_offset` from the API response
- `has_next` as the loop condition

## Important

This API does **not** physically pre-create 12M JSON records. It generates each requested batch deterministically. That makes it practical for testing pagination and large-volume ingestion without needing several GB of storage.

For an ADF production-style exercise, start with:

```text
limit = 1000
```

Then increase to:

```text
limit = 10000
```

and test throughput, retry handling, pagination, and ADLS partitioning.