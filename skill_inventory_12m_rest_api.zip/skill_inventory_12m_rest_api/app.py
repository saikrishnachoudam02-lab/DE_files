from fastapi import FastAPI, Query
from typing import Optional
import hashlib
from datetime import datetime, timedelta

app = FastAPI(
    title="Skill Inventory 12M Mock REST API",
    description="Paginated REST API for ADF/Databricks ingestion testing",
    version="1.0.0"
)

TOTAL_RECORDS = 12_000_000

first_names = ["Arun","Priya","Rahul","Sneha","Kiran","Anil","Divya","Vikram","Neha","Ravi"]
last_names = ["Kumar","Reddy","Sharma","Patel","Singh","Rao","Das","Nair","Verma","Iyer"]
skills = ["Python","PySpark","SQL","Azure","Databricks","ADF","Snowflake","dbt","Kafka","Airflow"]
levels = ["Beginner","Intermediate","Advanced","Expert"]
statuses = ["Completed","In Progress","Not Started"]

def make_record(i: int):
    # Deterministic pseudo-random values: same ID always produces same record.
    h = int(hashlib.md5(str(i).encode()).hexdigest()[:12], 16)

    first = first_names[h % len(first_names)]
    last = last_names[(h // 7) % len(last_names)]
    skill = skills[(h // 13) % len(skills)]
    level = levels[(h // 17) % len(levels)]
    status = statuses[(h // 19) % len(statuses)]

    base_date = datetime(2024, 1, 1)
    completed_date = base_date + timedelta(days=h % 1000)

    return {
        "employee_id": f"EMP{i:08d}",
        "employee_name": f"{first} {last}",
        "email": f"{first.lower()}.{last.lower()}{i}@example.com",
        "skill_id": f"SKL{(h % 5000) + 1:05d}",
        "skill_name": skill,
        "skill_level": level,
        "completion_status": status,
        "score": (h % 101),
        "course_id": f"COURSE{(h % 20000) + 1:06d}",
        "course_name": f"{skill} Learning Path",
        "completed_date": completed_date.strftime("%Y-%m-%d"),
        "source_system": "CloudAcademy",
        "updated_at": (completed_date + timedelta(hours=h % 24)).isoformat()
    }

@app.get("/")
def root():
    return {
        "api": "Skill Inventory Mock REST API",
        "total_records": TOTAL_RECORDS,
        "record_type": "employee_skill_inventory",
        "pagination": "offset/limit",
        "example": "/api/v1/skill-inventory?offset=0&limit=1000"
    }

@app.get("/api/v1/health")
def health():
    return {"status": "healthy", "total_records": TOTAL_RECORDS}

@app.get("/api/v1/skill-inventory")
def skill_inventory(
    offset: int = Query(0, ge=0),
    limit: int = Query(1000, ge=1, le=10000),
    skill: Optional[str] = None,
    status: Optional[str] = None
):
    if offset >= TOTAL_RECORDS:
        return {
            "data": [],
            "pagination": {
                "offset": offset,
                "limit": limit,
                "returned": 0,
                "total": TOTAL_RECORDS,
                "has_next": False,
                "next_offset": None
            }
        }

    end = min(offset + limit, TOTAL_RECORDS)
    records = [make_record(i) for i in range(offset + 1, end + 1)]

    if skill:
        records = [r for r in records if r["skill_name"].lower() == skill.lower()]
    if status:
        records = [r for r in records if r["completion_status"].lower() == status.lower()]

    return {
        "data": records,
        "pagination": {
            "offset": offset,
            "limit": limit,
            "returned": len(records),
            "total": TOTAL_RECORDS,
            "has_next": end < TOTAL_RECORDS,
            "next_offset": end if end < TOTAL_RECORDS else None
        }
    }